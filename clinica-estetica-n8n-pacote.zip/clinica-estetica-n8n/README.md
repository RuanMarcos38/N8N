# Clínica de Estética — Fluxo n8n com Agente IA, WhatsApp, Supabase e Evolution API

Este pacote contém um fluxo completo para atendimento de clínica de estética no WhatsApp com IA, agendamento, cancelamento, reagendamento, follow-up, lembretes e pós-atendimento.

## Arquivos

- `workflow-completo-clinica-estetica-n8n.json` — arquivo principal para importar no n8n.
- `supabase-schema.sql` — tabelas necessárias no Supabase.
- `.env.example` — variáveis que precisam ser configuradas no n8n.

## O que o fluxo faz

1. Recebe mensagens do WhatsApp via webhook da Evolution API.
2. Normaliza telefone, nome, mensagem, tipo e ID da mensagem.
3. Salva contato e histórico no Supabase.
4. Busca histórico recente da conversa.
5. Envia contexto para OpenAI.
6. O agente IA decide a intenção e a ação: responder, consultar horários, criar agendamento, cancelar, reagendar ou encaminhar humano.
7. Simula “digitando” com Evolution API.
8. Aplica pausa humanizada antes da resposta.
9. Envia mensagem no WhatsApp.
10. Atualiza status do cliente.
11. Executa follow-up automático para clientes sem resposta.
12. Envia lembretes de agendamento.
13. Envia pós-atendimento e pedido de avaliação.

## Antes de importar

1. Crie o projeto no Supabase.
2. Execute o arquivo `supabase-schema.sql` no SQL Editor.
3. Configure a Evolution API e conecte sua instância do WhatsApp.
4. Tenha uma chave OpenAI válida.
5. No n8n, configure as variáveis de ambiente abaixo.

## Variáveis de ambiente necessárias

```env
EVOLUTION_BASE_URL=https://sua-evolution-api.com
EVOLUTION_API_KEY=sua-chave-evolution
INSTANCE_NAME=clinica-estetica

SUPABASE_URL=https://seuprojeto.supabase.co
SUPABASE_SERVICE_ROLE=sua-service-role-key

OPENAI_API_KEY=sua-chave-openai
OPENAI_MODEL=gpt-4o-mini

CLINICA_NOME=Nome da Clínica
CLINICA_ENDERECO=Rua Exemplo, 000 - Centro - Sua Cidade
CLINICA_WHATSAPP=5547999999999
CLINICA_HORARIO=Segunda a sexta 08h às 19h, sábado 08h às 13h
CLINICA_LINK_AVALIACAO=https://g.page/r/SEU-LINK-DE-AVALIACAO
```

## Como importar no n8n

1. Acesse o n8n.
2. Vá em **Workflows**.
3. Clique em **Import from File**.
4. Selecione `workflow-completo-clinica-estetica-n8n.json`.
5. Abra os nodes HTTP Request e confira as URLs/variáveis.
6. Salve o workflow.
7. Ative o workflow.
8. Copie a URL do node `Webhook WhatsApp Evolution`.
9. Configure essa URL como webhook na Evolution API.

## Webhook da Evolution API

Configure o webhook da sua instância para enviar eventos de mensagens recebidas para o endpoint do n8n:

```text
POST https://SEU-N8N/webhook/clinica-estetica-whatsapp
```

## Observações importantes

- O fluxo foi montado usando HTTP Request para evitar dependência de credenciais internas do n8n. Assim, você só precisa configurar variáveis de ambiente.
- A IA responde em JSON para facilitar a automação das ações.
- O fluxo evita mensagens duplicadas usando histórico, status e contagem de follow-up.
- O cancelamento pede confirmação antes de cancelar quando o cliente não deixa a confirmação clara.
- Dúvidas médicas sensíveis são encaminhadas para atendimento humano.
- Para Google Calendar, recomendo acrescentar um node Google Calendar após `Criar Agendamento`, usando os campos `data_iso`, `horario_normalizado`, `hora_fim`, `procedimento` e `nome_cliente`.

## Status usados

- `novo`
- `em_atendimento`
- `qualificando`
- `interessado`
- `aguardando_horario`
- `aguardando_confirmacao`
- `agendado`
- `cancelamento_solicitado`
- `cancelado`
- `reagendamento_solicitado`
- `reagendado`
- `aguardando_humano`
- `finalizado`
- `sem_resposta`
- `perdido`

## Procedimentos padrão no prompt

- Limpeza de pele
- Botox
- Preenchimento labial
- Bioestimulador de colágeno
- Peeling químico
- Microagulhamento
- Depilação a laser
- Drenagem linfática
- Massagem modeladora
- Radiofrequência
- Harmonização facial
- Skinbooster
- Tratamento para melasma
- Tratamento para acne
- Design de sobrancelhas
- Lash lifting
- Avaliação estética

## Próximos ajustes recomendados

Depois de importar, personalize:

1. Nome real da clínica.
2. Endereço real.
3. Procedimentos reais.
4. Tabela de valores, caso queira que a IA informe preços.
5. Duração real de cada procedimento.
6. Profissionais e salas disponíveis.
7. Mensagens de lembrete e pós-atendimento.
8. Link de avaliação do Google.
