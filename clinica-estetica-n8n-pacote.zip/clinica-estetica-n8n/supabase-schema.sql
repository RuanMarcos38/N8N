-- Schema Supabase para Agente IA Clínica de Estética
-- Execute no SQL Editor do Supabase antes de ativar os workflows.

create extension if not exists pgcrypto;

create table if not exists contatos (
  id uuid primary key default gen_random_uuid(),
  telefone text unique not null,
  nome text,
  status text default 'novo',
  etapa text default 'inicio',
  procedimento_interesse text,
  origem text default 'whatsapp',
  atendimento_humano boolean default false,
  followup_count int default 0,
  ultimo_followup_em timestamp with time zone,
  ultima_mensagem_direcao text,
  ultima_mensagem_em timestamp with time zone default now(),
  resumo_contexto text,
  criado_em timestamp with time zone default now(),
  atualizado_em timestamp with time zone default now()
);

create table if not exists mensagens (
  id uuid primary key default gen_random_uuid(),
  telefone text not null,
  contato_id uuid references contatos(id) on delete set null,
  direcao text not null check (direcao in ('entrada','saida','sistema')),
  mensagem text,
  tipo text default 'texto',
  intencao text,
  message_id text,
  criado_em timestamp with time zone default now()
);

create table if not exists agendamentos (
  id uuid primary key default gen_random_uuid(),
  contato_id uuid references contatos(id) on delete set null,
  telefone text not null,
  nome_cliente text,
  procedimento text,
  profissional text,
  data_agendamento date,
  hora_inicio time,
  hora_fim time,
  status text default 'solicitado' check (status in ('solicitado','confirmado','cancelado','reagendado','concluido','nao_compareceu')),
  google_event_id text,
  lembrete_24h_enviado boolean default false,
  lembrete_2h_enviado boolean default false,
  pos_atendimento_enviado boolean default false,
  observacoes text,
  criado_em timestamp with time zone default now(),
  atualizado_em timestamp with time zone default now()
);

create table if not exists followups (
  id uuid primary key default gen_random_uuid(),
  contato_id uuid references contatos(id) on delete set null,
  telefone text not null,
  etapa text,
  numero_followup int default 1,
  mensagem text,
  enviado_em timestamp with time zone default now()
);

create table if not exists horarios_bloqueados (
  id uuid primary key default gen_random_uuid(),
  data date not null,
  hora_inicio time not null,
  hora_fim time not null,
  motivo text,
  profissional text,
  criado_em timestamp with time zone default now()
);

create index if not exists idx_contatos_telefone on contatos(telefone);
create index if not exists idx_contatos_status on contatos(status);
create index if not exists idx_mensagens_telefone_criado on mensagens(telefone, criado_em desc);
create index if not exists idx_agendamentos_telefone_status on agendamentos(telefone, status);
create index if not exists idx_agendamentos_data_status on agendamentos(data_agendamento, status);

-- Políticas: mantenha RLS habilitado se usar no frontend.
-- Para uso via n8n, utilize SUPABASE_SERVICE_ROLE nos headers Authorization.
