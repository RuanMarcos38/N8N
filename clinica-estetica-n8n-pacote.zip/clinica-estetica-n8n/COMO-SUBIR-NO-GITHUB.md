# Como subir este pacote no GitHub

A integração tentou gravar diretamente no repositório, mas retornou bloqueio/permissão 403. Para subir manualmente:

```bash
git clone https://github.com/RuanMarcos38/N8N.git
cd N8N
mkdir -p clinica-estetica-n8n
# Copie todos os arquivos deste pacote para a pasta clinica-estetica-n8n

git add clinica-estetica-n8n
git commit -m "Adicionar fluxo n8n para clínica de estética"
git push origin main
```

Se o repositório estiver vazio e pedir inicialização:

```bash
git branch -M main
git remote add origin https://github.com/RuanMarcos38/N8N.git
git add .
git commit -m "Adicionar fluxo n8n para clínica de estética"
git push -u origin main
```
